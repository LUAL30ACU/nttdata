package com.bootcampjava.event.service;

import com.bootcampjava.event.web.model.EventModel;

import java.util.List;

public interface IEventService {
	
	List<EventModel> findAll() throws Exception;
//	List<Event> findmonto(Double montototal);

	EventModel findById(Long id) throws Exception;
	
	List<EventModel> findByNameAndDescription(String name, String Description) throws Exception;

	EventModel create(EventModel eventModel) throws Exception;

	void update(Long id, EventModel eventModel) throws Exception;

	void deleteById(Long id) throws Exception;






}