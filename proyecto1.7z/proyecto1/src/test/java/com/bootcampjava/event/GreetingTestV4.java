package com.bootcampjava.event;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Objects;

import static org.junit.jupiter.api.Assumptions.assumeFalse;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

class GreetingTestV4 {
	
	private Greeting greeting;
	
	@BeforeEach
	void setUp() {
		greeting = new Greeting();
	}
	
	@Test
	void assumeIsTrue() {
		assumeTrue(Objects.equals(greeting.helloWorld("BootCamp BC25"), "Hello World"));
	}
	
	@Test
	void assumeIsFalse() {
		assumeFalse(Objects.equals(greeting.helloWorld("Bootcamp BC25"), "Hello BootCamp BC25"));
	}
	
}
