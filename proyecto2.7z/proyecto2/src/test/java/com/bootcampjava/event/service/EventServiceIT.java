package com.bootcampjava.event.service;

import com.bootcampjava.event.domain.Event;
import com.bootcampjava.event.repository.EventRepository;
import com.bootcampjava.event.service.mapper.EventMapper;
import com.bootcampjava.event.web.model.EventModel;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;

@SpringBootTest(classes = {EventMapper.class})
class EventServiceIT {

	@Mock
	EventRepository eventRepository;
	
	@Spy
	private EventMapper eventMapper = Mappers.getMapper(EventMapper.class);
	 
	
	EventService eventService;
	
	@BeforeEach
	void beforeEach() {
		eventService = new EventService(eventRepository, eventMapper);
	}
		
	@Test
	void create() throws Exception 
	{
		 //given
		 Event event = Event.builder()
				 	   .id(Long.valueOf(1))
				 	   .name("Bootcamp BCJava25")
				 	   .description("Java")
				 	   .dateEvent(Timestamp.from(Instant.now()))
				 	   .build();

		 given(eventRepository.save(any(Event.class))).willReturn(event);
		 
		 //when		
		 EventModel eventsToCreate = eventMapper.eventToEventModel(event);
	     EventModel eventsCreated = eventService.create(eventsToCreate);
	     
	     //then
	     then(eventRepository).should().save(any(Event.class));
	     assertThat(eventsCreated).isNotNull();
	}
	
	@Test
	void update() throws Exception 
	{
		 //given
		 Event event = Event.builder()
				 	   .id(Long.valueOf(1))
				 	   .name("Bootcamp BCJava25")
				 	   .description("Java")
				 	   .dateEvent(Timestamp.from(Instant.now()))
				 	   .build();
		 given(eventRepository.findById(Long.valueOf(1))).willReturn(Optional.of(event));
	 
		 //when		
		 EventModel eventsToUpdate = eventMapper.eventToEventModel(event);
	     eventService.update(Long.valueOf(1), eventsToUpdate);
	     
	     //then
	     then(eventRepository).should().save(any(Event.class));
	}
	
	@Test
	void updateNotFound() throws Exception 
	{
		Event event = Event.builder()
		 	   .id(Long.valueOf(1))
		 	   .name("Bootcamp BCJava25")
		 	   .description("Java")
		 	   .dateEvent(Timestamp.from(Instant.now()))
		 	   .build();
		 EventModel eventsToUpdate = eventMapper.eventToEventModel(event);
		    
		 assertThrows(Exception.class, () -> eventService.update(Long.valueOf(1), eventsToUpdate));
	}
		
	@Test
	void findAll() throws Exception 
	{
		 //given
		 List<Event> events = new ArrayList<Event>();
		 events.add(Event.builder()
				 	.name("Bootcamp BCJava25")
				 	.description("Java")
				 	.dateEvent(Timestamp.from(Instant.now()))
				 	.build());
		 
		 events.add(Event.builder()
				 	.name("Bootcamp BCJava26")
				 	.description("Java")
				 	.dateEvent(Timestamp.from(Instant.now()))
				 	.build());
		 
		 given(eventRepository.findAll()).willReturn(events);
		 
		 //when
	     List<EventModel> eventsFindAll = eventService.findAll();
	     
	     //then
	     then(eventRepository).should().findAll();
	     assertThat(eventsFindAll).isNotNull();
	}
	
	@Test
	void findById() throws Exception 
	{
		 //given
		 Event event = new Event();
		 given(eventRepository.findById(Long.valueOf(1))).willReturn(Optional.of(event));
		 
		 //when
	     EventModel eventsFindById = eventService.findById(Long.valueOf(1));
	     
	     //then
	     then(eventRepository).should().findById(Long.valueOf(1));
	     assertThat(eventsFindById).isNotNull();
	}
	
	@Test
	void findByIdNotFound() throws Exception 
	{
		 assertThrows(Exception.class, () -> eventService.findById(Long.valueOf(1)));
	}
	
	@Test
	void findByNameAndDescription() throws Exception
	{
		 //given
		 List<Event> events = new ArrayList<Event>();
		 events.add(Event.builder()
				 	.name("Bootcamp BCJava25")
				 	.description("Java")
				 	.dateEvent(Timestamp.from(Instant.now()))
				 	.build());
	
		 
		 given(eventRepository.findByNameIgnoreCaseAndDescriptionIgnoreCase(
				 "Bootcamp BCJava25", "Java"))
				 .willReturn(events);
		 
		 //when
	     List<EventModel> eventsFindAll = eventService.findByNameAndDescription(
	    		 "Bootcamp BCJava25", 
	    		 "Java");
	     
	     //then
	     then(eventRepository).should().findByNameIgnoreCaseAndDescriptionIgnoreCase(
	    		 "Bootcamp BCJava25", 
	    		 "Java");
	     assertThat(eventsFindAll).isNotNull();
	}
		
	@Test
	void deleteById() throws Exception{
		 //given
		 
		 //when		
	     eventService.deleteById(Long.valueOf(1));
	     
	     //then
	     then(eventRepository).should().deleteById(anyLong());
	}
	

}
