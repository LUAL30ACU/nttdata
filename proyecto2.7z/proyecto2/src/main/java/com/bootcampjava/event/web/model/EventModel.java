package com.bootcampjava.event.web.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import jdk.jshell.Snippet;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.test.context.SpringBootTest;
import org.testng.annotations.Test;

import javax.validation.constraints.Future;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.sql.Timestamp;

@Data
@NoArgsConstructor
@AllArgsConstructor
//nombres,apellidos,del cliente tipodecliente,tipodecuenta,saldos,transaccion
public class EventModel {

	public static Snippet builder;
	@JsonProperty("eventId")
	private Long id;
	
    @NotBlank(message="Nombre del cliente no puede ser vacio")
    private String name;
	@NotBlank(message="apellido no puede ser vacio")
	private String surnames;
	@NotBlank(message="tipo  de cliente no puede ser vacio")
	private String customertype;
	@NotBlank(message="tipo de cuenta no puede ser vacio")
	private String accountype;

	private String  transaccion;

	//@NotBlank(message="monto de transaccion no puede ser vacio")
	public Long mounttransaccion;
	public Long balances;


   // private String description;

	//public Double result;
	//public Double resultuno;
	@JsonProperty("date")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm")
    @NotNull(message="Fecha de transaccion no puede ser vacio")
	@Future
	private Timestamp dateEvent;
	
	private CategoryModel category;
	
	private PlaceModel place;



@SpringBootTest
class MicroservicioApplicationTests {

	@Test
	void contextLoads() {
	}
}
}