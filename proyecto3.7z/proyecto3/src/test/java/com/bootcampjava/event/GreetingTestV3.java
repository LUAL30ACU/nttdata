package com.bootcampjava.event;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Objects;

import static org.junit.jupiter.api.Assertions.*;

class GreetingTestV3 {
	
	private Greeting greeting;
	
	@BeforeEach
	void setUp() {
		greeting = new Greeting();
	}
	
	@Test
	void helloWorld() {
        assertEquals("Hello BootCamp BC25", greeting.helloWorld("BootCamp BC25"));
	}
	
	@Test
	void notEqualsGreeting() {
        assertNotEquals("Hello BootCamp BC25", greeting.helloWorld("Bootcamp BC25"));
	}
	
	@Test
	void conditionalTest() {
		assertTrue(Objects.equals(greeting.helloWorld("Bootcamp BC25"), "Hello World"));
		assertFalse(Objects.equals(greeting.helloWorld("BootCamp BC25"), "BootCamp BC25"));
	}
	
	@Test
	@DisplayName("Test exception")
	void oupsHandler() {
		assertThrows(NumberFormatException.class, () -> { Integer.parseInt("Hola");});
	}	
	
}
