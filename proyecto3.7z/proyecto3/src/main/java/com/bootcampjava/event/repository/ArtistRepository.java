package com.bootcampjava.event.repository;

import com.bootcampjava.event.domain.Artist;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ArtistRepository extends JpaRepository<Artist, Long>  {

}
