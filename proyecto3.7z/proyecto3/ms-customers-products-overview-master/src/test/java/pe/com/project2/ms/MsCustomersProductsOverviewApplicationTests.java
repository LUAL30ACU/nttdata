package pe.com.project2.ms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsCustomersProductsOverviewApplicationTests {

	@Test
	void contextLoads() {
	}

}
