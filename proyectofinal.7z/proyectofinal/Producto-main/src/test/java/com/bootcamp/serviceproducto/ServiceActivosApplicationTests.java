package com.bootcamp.serviceproducto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceActivosApplicationTests {

	@Test
	void contextLoads() {
	}

}
