package com.bootcamp.servicecliente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicePersonalApplicationTests {

	@Test
	void contextLoads() {
	}

}
