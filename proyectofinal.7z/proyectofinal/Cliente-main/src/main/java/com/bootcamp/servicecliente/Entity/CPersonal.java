package com.bootcamp.servicecliente.Entity;

public class CPersonal {
}
