package com.bootcampjava.event.repository;

import com.bootcampjava.event.domain.Schedule;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ScheduleRepository extends JpaRepository<Schedule, Long>  {

}
