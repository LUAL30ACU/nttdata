package com.bootcampjava.event.web;

import com.bootcampjava.event.service.IEventService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@AutoConfigureMockMvc
@WebMvcTest(EventController.class)
class EventControllerIT {
	
	@MockBean
	private IEventService eventService;

	//@Autowired
	private MockMvc mockMvc;

	@Test
	void getAll() throws Exception {
		mockMvc.perform(get("/v1/event").contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());

	}

	@Test
	void getById() throws Exception {
		mockMvc.perform(get("/v1/event/1").contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
	}

	@Test
	void create() throws Exception {
		//EventModel event = EventModel.builder().id(Long.valueOf(1)).name("Bootcamp BCJava25").description("Java")
		//		.dateEvent(Timestamp.valueOf(LocalDateTime.of(2022,10,11,5,14))).build();

		//mockMvc.perform(MockMvcRequestBuilders.post("/v1/event").content(asJsonString(event))
		//		.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
	}

	@Test
	void update() throws Exception {
		//EventModel event = EventModel.builder().id(Long.valueOf(1)).name("Bootcamp BCJava25").description("Java")
			//	.dateEvent(Timestamp.valueOf(LocalDateTime.of(2022,10,11,5,14))).build();

		//mockMvc.perform(MockMvcRequestBuilders.put("/v1/event/1").content(asJsonString(event))
			//	.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk());

	}

	@Test
	void deleteById() throws Exception {
		mockMvc.perform(delete("/v1/event/1").contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
	}

	public static String asJsonString(final Object obj) throws JsonProcessingException {

		return new ObjectMapper().writeValueAsString(obj);
	}

	
	
}
