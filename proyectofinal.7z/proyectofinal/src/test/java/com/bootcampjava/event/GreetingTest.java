package com.bootcampjava.event;

import org.junit.jupiter.api.Test;

public class GreetingTest {
	
	@Test
	void helloWorld() {
        System.out.println("Hello BootCamp BC25");
	}
}
