package com.sacavix.events;

public enum EventType {
	CREATED, UPDATED, DELETED
}
