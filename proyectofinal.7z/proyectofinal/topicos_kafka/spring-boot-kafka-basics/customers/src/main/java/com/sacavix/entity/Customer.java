package com.sacavix.entity;

import lombok.Data;

@Data
/** define los tipos de datos para el servicio P2P con su moneda virtual BootCoin */
public class Customer {
	private Long id;
	private String name;
	private String email;
	private String dni;
	private String celular;
	private Double mount;
}
