package com.bootcampjava.event.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Columns;

import javax.persistence.*;
import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;
import java.sql.Timestamp;
import java.util.Set;

@Data
@Builder
@Entity
@NoArgsConstructor
@AllArgsConstructor
public class Event {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	//lista de clientes y productos bancarios, clientes tipodecuentas tipodeproductos o productos montos
	@NotNull
	@Column(unique=true)
	private String name;
	/**NOMBRECOLUMNAS
	 * */
	private String description;
	@Column
	private String surnames;
	@Column
	private String customertype;
	@Column
	private String  accountype;
	@Column
	private String  transaccion;
	@Column
	public Long mounttransaccion;
	@Column
	public Long balances;


	@NotNull
	@Future
	private Timestamp dateEvent;
	
	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	private Category category;
	
	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	private Place place;
	
	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	private Set<Schedule> schedule;
	
}
