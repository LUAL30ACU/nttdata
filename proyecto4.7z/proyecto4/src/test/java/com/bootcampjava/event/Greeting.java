package com.bootcampjava.event;

public class Greeting {
    public boolean helloWorld(String bootcamp_bc25) {
        return false;
    }
}
