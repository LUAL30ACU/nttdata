package com.bootcampjava.event;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class GreetingTestV2 {
	
	private Greeting greeting;
	
	@BeforeAll
	static void initialize() {
		System.out.println("Before - I am only called Once!!!");
	}
	
	@BeforeEach
	void setup() {
		System.out.println("In Before Each....");
		greeting = new Greeting();
	}
	
	@Test
	void helloWorld() {
		System.out.println(greeting.helloWorld("Bootcamp BC25"));
	}
	
	@Test
	void helloWorld2() {
		System.out.println(greeting.helloWorld("Bootcamp BC25"));
	}
}
