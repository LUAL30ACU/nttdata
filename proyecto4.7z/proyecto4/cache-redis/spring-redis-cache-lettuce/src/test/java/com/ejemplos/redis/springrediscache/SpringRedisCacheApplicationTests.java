package com.ejemplos.redis.springrediscache;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRedisCacheApplicationTests {

    @Test
    void contextLoads() {
    }

}
