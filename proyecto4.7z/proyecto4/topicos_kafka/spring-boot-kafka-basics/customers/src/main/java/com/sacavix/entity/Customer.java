package com.sacavix.entity;

import lombok.Data;

@Data
public class Customer {
	private Long id;
	private String name;
	private String email;
	private String dni;
	private String celular;
	private Double mount;
}
